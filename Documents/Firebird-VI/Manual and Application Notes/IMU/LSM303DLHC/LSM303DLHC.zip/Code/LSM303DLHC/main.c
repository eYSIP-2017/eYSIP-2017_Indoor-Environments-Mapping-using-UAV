/**************************************************************************************************
		Platform: LPC2148 Development Board.
		
		Written by: Rohit Chauhan, NEX Robotics Pvt. Ltd.
		Edited By: Sachitanand Malewar, NEX Robotics Pvt. Ltd.
		Last Modification: 2011-12-13

		
		 
		Compiled with: RealView MDK-ARM Version:4.12 

		Hardware Setup:-
        Insert all LCD jumpers.
		P0.2 configured as I2C clock
		P0.3 configured as I2C Address/Data
		Use on board 50pin expansion header 3.3V or 5V for power I2C connections with LSM303DLHC module.
		
		        
		Clock Settings:
		FOSC	>>	12MHz (onboard)
		PLL		>>	M=5, P=2
		CCLK	>>  60MHz
		PCLK	>>  15MHz 
**************************************************************************************************/

/********************************************************************************

   Copyright (c) 2011, NEX Robotics Pvt. Ltd.                       -*- c -*-
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the copyright holders nor the names of
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   * Source code can be used for academic purpose. 
	 For commercial use permission form the author needs to be taken.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE. 

  Software released under Creative Commence cc by-nc-sa licence.
  For legal information refer to: 
  http://creativecommons.org/licenses/by-nc-sa/3.0/legalcode

********************************************************************************/ 
#include <lpc214x.h>		   //Includes LPC2148 register definitions
#include <stdlib.h>
#include "LCD.h"
#include "i2c.h"


/********************Common Definitions***************************************/
#define MAX_BUFFER_SIZE		16

#define LED1_ON() IO1SET=(1<<16)		
#define LED2_ON() IO1SET=(1<<17)		//I2C read indicator
#define LED3_ON() IO1SET=(1<<18)		//Comm failure indicator
#define LED4_ON() IO1SET=(1<<19)		

#define LED1_OFF() IO1CLR=(1<<16)	
#define LED2_OFF() IO1CLR=(1<<17)
#define LED3_OFF() IO1CLR=(1<<18)
#define LED4_OFF() IO1CLR=(1<<19)
/******************************************************************************/


/*************************Function Prototypes**********************************/
void Delay_Ticks(unsigned int j);  //Function to generate delay in msec
void __irq I2C0_Status(void);
unsigned char GetXYZAcc(void);
unsigned char GetXYZMag(void);
/******************************************************************************/


/***********************Global Variables***************************************/
unsigned char I2C_WR_Buf[MAX_BUFFER_SIZE];
unsigned char I2C_RD_Buf[MAX_BUFFER_SIZE];
unsigned char Status=0;
unsigned char Status_Flag=0;
unsigned char I2C_Data=0;

signed short int X_Acc,Y_Acc,Z_Acc=0;
signed short int X_Mag,Y_Mag,Z_Mag=0;
float Displacement;
/*****************************************************************************/


/*****************************************************************************/
void Delay_Ticks(unsigned int j)  //Function to generate delay in msec
{  
   unsigned int  i;
   for(;j>0;j--)
   {
    for(i=0; i<10000; i++);
   } 
}
/*****************************************************************************/


void InitializeBoard(void)
{
  PINSEL0 = 0x00000000;		// Enable GPIO on all pins
  PINSEL1 = 0x00000000;
  PINSEL2 = 0x00000000;
  IO0DIR = 0x007F0000;		// Set P0.16, P0.17, P0.18, P0.19, P0.20, P0.21, P0.22 as Output, P0.12, P0.13,P0.15 & P0.30 as input
  IO1DIR = (1<<19) | (1<<18) | (1<<17) | (1<<16);		// Set P1.16, P1.17, P1.18, P1.19 as Output
  LED1_OFF();LED2_OFF();LED3_OFF();LED4_OFF();
  I2C_Init();
  Delay_Ticks(100);		    //100 mSec Power ON delay for LCD
  LCD_Init();
  LCD_Command(0x01);
  Delay_Ticks(15);
}

/*
	 This function get Accelerometer XYZ parameters through I2C bus
*/
unsigned char GetXYZAcc(void)
{
  unsigned char Temp=0;
  LED2_ON();	//Read indicator
  if(Read_Multi_Byte(DEVICE_ADDR_ACC,0x80 | STATUS_REG_A))
  {
   LED3_ON();
   while(1);
  }
  else
  {  
   if((I2C_RD_Buf[0] & 0x08)==0x08)
   {
    X_Acc = I2C_RD_Buf[1];
    X_Acc|= (signed short int)I2C_RD_Buf[2] << 8;
          
    Y_Acc = I2C_RD_Buf[3];
    Y_Acc|= (signed short int)I2C_RD_Buf[4] << 8;
        
    Z_Acc = I2C_RD_Buf[5];
    Z_Acc|= (signed short int)I2C_RD_Buf[6] << 8;
     
	I2C_RD_Buf[0] = 0x00;
	Temp = 1;
   }
   else
   {
    Temp = 0;
   }
  }
  LED2_OFF();
  return (Temp);
}

/*
	 This function get Magnetometer XYZ parameters through I2C bus
*/
unsigned char GetXYZMag(void)
{
  unsigned char Temp=0;
  LED2_ON();	//Read indicator

  if(Read_I2C_Byte(DEVICE_ADDR_MAG,SR_REG_MG))  //Check if new data is available
  {
   LED3_ON();
   while(1);
  }
  else
  {
   if((I2C_Data & 0x01)==0x01)	  //IF new data is available
   {
    if(Read_Multi_Byte(DEVICE_ADDR_MAG,MR_REG_M))    //Read new data
    {
     LED3_ON();
     while(1);			//if read fails loop here
    }
    else			    //Buffer new data
    {  
     X_Mag = I2C_RD_Buf[2];
     X_Mag|= (signed short int)I2C_RD_Buf[1] << 8;
      
     Y_Mag = I2C_RD_Buf[4];
     Y_Mag|= (signed short int)I2C_RD_Buf[3] << 8;
      
     Z_Mag = I2C_RD_Buf[6];
     Z_Mag|= (signed short int)I2C_RD_Buf[5] << 8;
      
	 Temp = 1;
    }
   }
   else
   {
    Temp = 0;
   }
  }
  LED2_OFF();
  return (Temp);
}


int main(void)
{  
 InitializeBoard();
 LCD_String(1,1,"   LSM303DLHC   ");
 LCD_String(2,1,"   Test Setup   ");
 Delay_Ticks(2000);
 LCD_String(1,1,"                ");
 LCD_String(2,1,"X    Y    Z     ");
 
 Send_I2C_Byte(DEVICE_ADDR_ACC,CTRL_REG1_A,0x97);			//Normal Mode, 1344HZ, XYZ enabled 
 Send_I2C_Byte(DEVICE_ADDR_ACC,CTRL_REG4_A,0xA0);			//BDU update, Full scale selection +-8G
 
 Send_I2C_Byte(DEVICE_ADDR_MAG,CRA_REG_M,0x10);	  			//15Hz Output Rate, Temp Disabled
 Send_I2C_Byte(DEVICE_ADDR_MAG,CRB_REG_M,0x20);				//+-1.3 Guass,
 Send_I2C_Byte(DEVICE_ADDR_MAG,MR_REG_M,0x00);				//Continuous Conversion Mode
 
 while(1)
 {
  /**********************Accelerometer*******************************/
  /*          Accelerometer X,Y,Z sensitivity@ +-8g = 4mg/LSB		*/
  /*		  i.e. 1g = 250LSB or 1/0.004LSB						*/
  /*																*/
  /******************************************************************/
  if(GetXYZAcc())
  {
   if((X_Acc & 0x8000)==0x8000) {LCD_String(2,2,"-\0");}
   else						    {LCD_String(2,2,"+\0");}
   Displacement = ((float)X_Acc * 0.004 * 10.0)/16.0;
   X_Acc = (signed short int)Displacement;
   LCD_Print(2,3,abs(X_Acc),2);
   
   if((Y_Acc & 0x8000)==0x8000)	{LCD_String(2,7,"-\0");}
   else							{LCD_String(2,7,"+\0");}
   Displacement = ((float)Y_Acc * 0.004 * 10.0)/16.0;
   Y_Acc = (signed short int)Displacement;
   LCD_Print(2,8,abs(Y_Acc),2);

   if((Z_Acc & 0x8000)==0x8000)	{LCD_String(2,12,"-\0");}
   else							{LCD_String(2,12,"+\0");}
   Displacement = ((float)Z_Acc * 0.004 * 10.0)/16.0;
   Z_Acc = (signed short int)Displacement;   
   LCD_Print(2,13,abs(Z_Acc),2);
  }
  /*********************************************************************/
  
  /*********************   Magnetometer   ***************************/
  /*																*/
  /*	X Sensitivity @ +-1.3guass = 1100LSb/Gauss  				*/
  /*	Y Sensitivity @ +-1.3guass = 1100LSb/Gauss					*/
  /*	Z Sensitivity @ +-1.3guass = 980LSb/Gauss					*/
  /*																*/
  /******************************************************************/  
  if(GetXYZMag())
  {
   if((X_Mag & 0x8000)==0x8000)	{LCD_String(1,1,"-\0");}
   else							{LCD_String(1,1,"+\0");}
   Displacement = ((float)X_Mag / 1100.0) * 100.0;
   X_Mag = (signed short int)Displacement;
   LCD_Print(1,2,abs(X_Mag),3);
   
   if((Y_Mag & 0x8000)==0x8000)	{LCD_String(1,6,"-\0");}
   else							{LCD_String(1,6,"+\0");}
   Displacement = ((float)Y_Mag / 1100.0) * 100.0;
   Y_Mag = (signed short int)Displacement;
   LCD_Print(1,7,abs(Y_Mag),3);

   if((Z_Mag & 0x8000)==0x8000) {LCD_String(1,11,"-\0");}
   else							{LCD_String(1,11,"+\0");}
   Displacement = ((float)Z_Mag / 980.0) * 100.0;
   Z_Mag = (signed short int)Displacement;   
   LCD_Print(1,12,abs(Z_Mag),3);
  }
  /*********************************************************************/
  Delay_Ticks(50);
 }	
}

void  __irq I2C0_Status(void)
{ 
  Status_Flag=0xFF; 			//update status flag
  Status=I2C0STAT;				//Read Status byte
  I2C0CONCLR=0x28;				
  VICVectAddr = 0x00;   		//Acknowledge Interrupt
}
