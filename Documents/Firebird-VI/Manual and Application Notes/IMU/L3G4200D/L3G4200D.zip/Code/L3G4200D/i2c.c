#include <lpc214x.h>
#include "i2c.h"

#define MAX_BUFFER_SIZE 	16
#define DEVICE_ADDR 		0xD2	//L3G4200D I2C Address
#define READ 				1
#define WRITE 				0


extern void  __irq I2C0_Status(void);

extern unsigned char I2C_WR_Buf[MAX_BUFFER_SIZE];
extern unsigned char I2C_RD_Buf[MAX_BUFFER_SIZE];
extern unsigned char Status;
extern unsigned char Status_Flag;
extern unsigned char I2C_Data;

void I2C_Init(void)
{
 PINSEL0&=0xFFFFFF0F;
 PINSEL0|=0x00000050;

 I2C0CONCLR=0x6C;
 I2C0CONSET=0x40;
 I2C0SCLH=80;
 I2C0SCLL=70;

 /*  Init VIC for I2C0	*/
 VICIntSelect = 0x00000000;		// Setting all interrupts as IRQ(Vectored)
 VICVectCntl0 = 0x20 | 9;		// Assigning Highest Priority Slot to I2C0 and enabling this slot
 VICVectAddr0 = (unsigned long)I2C0_Status; // Storing vector address of I2C0
 VICIntEnable = (1<<9);	

}


void Send_Start()
{
 I2C0CONSET=0x20; 
}


void Send_Stop()
{
 I2C0CONSET=0x10;
}


unsigned char Send_I2C(unsigned char *Data,unsigned char Len)
{
 while(Len)
 {
  I2C0DAT=*Data;
  if(I2C_Status(0x28))
  {
   return 1;
  }
  Len--;
  Data++;
 }
 return 0;
}


unsigned char Read_I2C(unsigned char *Data,unsigned char Len)
{
 while(Len)
 {
  if(Len==1)  //Last byte
  {
   I2C0CONCLR=0x04;		 	 //set hardware to send nack
   if(I2C_Status(0x58))		 //last byte has been received and NACK has been returned
   {
    return 1;
   }
   *Data=I2C0DAT;
  }
  else
  {
   I2C0CONSET=0x04;	 		//set hardware to send  ack
   if(I2C_Status(0x50))	    //Byte has been received ACK has been returned
   {
    return 1;
   }
   *Data=I2C0DAT;	
  } 
  Data++;
  Len--;
 }
 return 0;
}


unsigned char I2C_Status(unsigned char status_code)
{
 while(Status_Flag==0);
 Status_Flag=0;
 if(Status!=status_code)
 {
  return 1;
 }
 else
 {
  return 0;
 }
}

unsigned char Read_Multi_Byte(unsigned char Reg_ADDR)
{
 Send_Start();
 if(I2C_Status(0x08))			//Start has been transmitted
 {
  return 1;
 }

 I2C0DAT=DEVICE_ADDR | WRITE;	// Send Address
 if(I2C_Status(0x18))			//Device address, block num and write has been transmitted
 {
  return 1;
 }

 I2C0DAT=Reg_ADDR;
 if(I2C_Status(0x28))	//Block address has been transmitted
 {
  return 1;
 }

 Send_Start();		     // Repeat Start
 if(I2C_Status(0x10))	//Repeated Start has been transmitted
 {
  return 1;
 }

 I2C0DAT=DEVICE_ADDR  | READ;			//Device address, read has been transmitted
 if(I2C_Status(0x40))	//
 {
  return 1;
 }
 if(Read_I2C(I2C_RD_Buf,7))			//Receive 7bytes of Data from EEPROM
 {
  Send_Stop();
  return 1;
 }
 Send_Stop();
 return 0;
}

unsigned char Send_I2C_Byte(unsigned char Reg_ADDR, unsigned char Data)
{
 Send_Start();
 if(I2C_Status(0x08))			//Start has been transmitted
 {
  return 1;
 }

 I2C0DAT=DEVICE_ADDR | WRITE;	// Send Address
 if(I2C_Status(0x18))			//Device address, block num and write has been transmitted
 {
  return 1;
 }

 I2C0DAT=Reg_ADDR;
 if(I2C_Status(0x28))			//Reg address has been transmitted
 {
  return 1;
 }

 I2C0DAT = Data;
 if(I2C_Status(0x28))		    //Data has been transmitted
 {
  Send_Stop();
  return 1;
  
 }
 else 
 {
  Send_Stop();
  return 0;
 }
}

unsigned char Read_I2C_Byte(unsigned char Reg_ADDR)
{
 Send_Start();
 if(I2C_Status(0x08))			//Start has been transmitted
 {
  return 1;
 }

 I2C0DAT=DEVICE_ADDR | WRITE;	// Send Address
 if(I2C_Status(0x18))			//Device address, block num and write has been transmitted
 {
  return 1;
 }

 I2C0DAT=Reg_ADDR;
 if(I2C_Status(0x28))	//Block address has been transmitted
 {
  return 1;
 }

 Send_Start();		     // Repeat Start
 if(I2C_Status(0x10))	//Repeated Start has been transmitted
 {
  return 1;
 }

 I2C0DAT=DEVICE_ADDR  | READ;			//Device address, read has been transmitted
 if(I2C_Status(0x40))	//
 {
  return 1;
 }

 I2C0CONCLR=0x04;		 	 //set hardware to send nack
 if(I2C_Status(0x58))		 //last byte has been received and NACK has been returned
 {
  Send_Stop();
  return 1;
 }
 I2C_Data = I2C0DAT;
 Send_Stop();
 return(0);
}

