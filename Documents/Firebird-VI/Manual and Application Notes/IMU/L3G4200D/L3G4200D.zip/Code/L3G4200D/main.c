/**************************************************************************************************
		Platform: LPC2148 Development Board.
		
		Written by: Rohit Chauhan, NEX Robotics Pvt. Ltd.
		Edited By: Sachitanand Malewar, NEX Robotics Pvt. Ltd.
		Last Modification: 2011-12-13

		
		 
		Compiled with: RealView MDK-ARM Version:4.12 

		Hardware Setup:-
        Insert all LCD jumpers.
		P0.2 configured as I2C clock
		P0.3 configured as I2C Address/Data
		Use on board 50pin expansion header 3.3V or 5V for power I2C connections with L3G4200D module.
		
		        
		Clock Settings:
		FOSC	>>	12MHz (onboard)
		PLL		>>	M=5, P=2
		CCLK	>>  60MHz
		PCLK	>>  15MHz 
**************************************************************************************************/

/********************************************************************************

   Copyright (c) 2011, NEX Robotics Pvt. Ltd.                       -*- c -*-
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   * Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

   * Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.

   * Neither the name of the copyright holders nor the names of
     contributors may be used to endorse or promote products derived
     from this software without specific prior written permission.

   * Source code can be used for academic purpose. 
	 For commercial use permission form the author needs to be taken.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE. 

  Software released under Creative Commence cc by-nc-sa licence.
  For legal information refer to: 
  http://creativecommons.org/licenses/by-nc-sa/3.0/legalcode

********************************************************************************/ 
#include  <lpc214x.h>		   //Includes LPC2148 register definitions
#include  <stdlib.h>
#include "LCD.h"
#include "i2c.h"


/*****************Common Definitions********************************/
#define MAX_BUFFER_SIZE 	16

#define LED1_ON() IO1SET=(1<<16)		
#define LED2_ON() IO1SET=(1<<17)		//I2C read indicator
#define LED3_ON() IO1SET=(1<<18)		//Comm failure indicator
#define LED4_ON() IO1SET=(1<<19)		

#define LED1_OFF() IO1CLR=(1<<16)	
#define LED2_OFF() IO1CLR=(1<<17)
#define LED3_OFF() IO1CLR=(1<<18)
#define LED4_OFF() IO1CLR=(1<<19)

/******************************************************************/


/*********************Function Prototypes**************************/
void Delay(unsigned char j);
void Init_UART0(void);
void UART0_SendByte(unsigned char data);
void UART0_SendStr(const unsigned char *str);
void SetZeroRate(void);
void  __irq I2C0_Status(void);
/******************************************************************/


/************************Blobal Variables**************************/
unsigned char I2C_WR_Buf[MAX_BUFFER_SIZE];
unsigned char I2C_RD_Buf[MAX_BUFFER_SIZE];
unsigned char Status=0;
unsigned char Status_Flag=0;
unsigned char I2C_Data=0;
signed short int X_Data,Y_Data,Z_Data=0;
signed short int X,Y,Z=0;
signed short int X_sign;
signed short int X_Zero_Rate,Y_Zero_Rate,Z_Zero_Rate=0;
float Displacement;
signed short int X_Disp,Y_Disp,Z_Disp=0;
/******************************************************************/

void Delay_Ticks(unsigned int j)  //Function to generate delay in msec
{  
   unsigned int  i;
   for(;j>0;j--)
   {
    for(i=0; i<10000; i++);
   } 
}


void SetZeroRate(void)
{
 unsigned int i=0;
 for(i=0;i<100;i++)
 {
  if(Read_Multi_Byte(0x80 | STATUS_REG))
  {
   LED3_ON();
  }
  else
  {  
   X_Data = I2C_RD_Buf[1];
   X_Data|= (signed short int)I2C_RD_Buf[2] << 8;
   X_Zero_Rate+= X_Data; 
      
   Y_Data = I2C_RD_Buf[3];
   Y_Data|= (signed short int)I2C_RD_Buf[4] << 8;
   Y_Zero_Rate+= Y_Data; 
   
   Z_Data = I2C_RD_Buf[5];
   Z_Data|= (signed short int)I2C_RD_Buf[6] << 8;
   Z_Zero_Rate+= Z_Data & 0xFFF; 
  }
 }
 X_Zero_Rate = X_Zero_Rate/100;
 Y_Zero_Rate = Y_Zero_Rate/100;
 Z_Zero_Rate = Z_Zero_Rate/100;
 
}

void InitializeBoard(void)
{
 PINSEL0 = 0x00000005;		// Enable GPIO on all pins
 PINSEL1 = 0x00000000;
 PINSEL2 = 0x00000000;
 IO0DIR = 0x007F0000;		// Set P0.16, P0.17, P0.18, P0.19, P0.20, P0.21, P0.22 as Output, P0.12, P0.13,P0.15 & P0.30 as input
 IO1DIR = (1<<19) | (1<<18) | (1<<17) | (1<<16);		// Set P1.16, P1.17, P1.18, P1.19 as Output
 LED1_OFF();LED2_OFF();LED3_OFF();LED4_OFF();
 I2C_Init();
 Delay_Ticks(100);		    //100 mSec Power ON delay for LCD
 LCD_Init();
 LCD_Command(0x01);
 Delay_Ticks(15);
}

unsigned char GetXYZRate(void)
{
  unsigned char Temp=0;
  LED4_OFF();
  LED2_ON();	//Read indicator
  if(Read_Multi_Byte(0x80 | STATUS_REG))
  {
   LED3_ON();
   while(1);
  }
  else
  {  
   if((I2C_RD_Buf[0] & 0x08)==0x08)
   {
    X_Data = I2C_RD_Buf[1];
    X_Data|= (signed short int)I2C_RD_Buf[2] << 8;
           
    Y_Data = I2C_RD_Buf[3];
    Y_Data|= (signed short int)I2C_RD_Buf[4] << 8;
    
	    
    Z_Data = I2C_RD_Buf[5];
    Z_Data|= (signed short int)I2C_RD_Buf[6] << 8;
     
	I2C_RD_Buf[0] = 0x00;

	Temp = 1;
   }
   else
   {
    Temp = 0;
   }
  }
  LED4_ON();
  LED2_OFF();
  return (Temp);
}


int main(void)
{  
 InitializeBoard();
 LCD_String(1,1,"    L3G4200D    ");
 LCD_String(2,1,"   Test Setup   ");
 Delay_Ticks(2000);
 LCD_Command(0xC0);
 LCD_String(2,1," X    Y    Z    ");
 
 if(Read_I2C_Byte(WHO_AM_I)) 			//WHO AM I
 {
  while(1);
 }
 Send_I2C_Byte(CTRL_REG1,0x0F);			//ODR=100Hz, BW = 12.5,Normal Mode, XYZ enable	
 Send_I2C_Byte(CTRL_REG4,0x90);			//BDU update, 500DPS
 
 while(1)
 {
  if(GetXYZRate())
  {
   Displacement = ((float)X_Data / 57.0) * 0.01 * 10.0;
   X_Data = (signed short int)Displacement;
   X_Disp+=X_Data;
   LCD_Print(2,3,abs(X_Disp),3);
   
   Displacement = ((float)Y_Data / 57.0) * 0.01 * 10.0;
   Y_Data = (signed short int)Displacement;
   Y_Disp+=Y_Data;
   LCD_Print(2,8,abs(Y_Disp),3);

   Displacement = ((float)Z_Data / 57.0) * 0.01 * 10.0;
   Z_Data = (signed short int)Displacement;
   Z_Disp+=Z_Data;
   LCD_Print(2,13,abs(Z_Disp),3);
  }
  Delay_Ticks(50);
 }	
}

void __irq I2C0_Status(void)
{ 
  Status_Flag=0xFF; 			//update status flag
  Status=I2C0STAT;				//Read Status byte
  I2C0CONCLR=0x28;				
  VICVectAddr = 0x00;   		//Acknowledge Interrupt
}




	