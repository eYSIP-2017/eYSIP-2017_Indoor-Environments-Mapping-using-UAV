#include<LPC214x.h>
#include "LCD.h"


void LCD_Delay(unsigned char j)		//Generates delay of app 100usec
{
 unsigned int  i;
 for(;j>0;j--)
 {
  for(i=0; i<1000; i++);
 } 
}
                               
unsigned char Busy_Wait()			   //This function checks the busy status of LCD
{
 unsigned int temp=0;
 EN_LOW();
 COMMAND_PORT();
 READ_DATA();
 
 IO0PIN&=0xFF87FFFF;	  
 IO0DIR&=0xFF87FFFF;
 IO0PIN|=0x00400000;
 
 do{
 EN_HI();
 EN_LOW();
 EN_HI();
 EN_LOW();
 temp=IO0PIN;
 }
 while((temp & 0x00400000)==0x00400000);
 EN_LOW();
 WRITE_DATA();
 IO0DIR&=0xFF80FFFF;
 IO0DIR|=0x007F0000;
 return (0);
}    


void LCD_Command(unsigned int data)			  //This function is used to send LCD commands
{
 unsigned int temp=0;
 EN_LOW();
 COMMAND_PORT();
 WRITE_DATA();
 
 temp=data;
 IO0PIN&=0xFF87FFFF;
 IO0PIN|=(temp & 0xF0) << 15;

 EN_HI();
 EN_LOW();
 
 temp=data & 0x0F;
 IO0PIN&=0xFF87FFFF;
 IO0PIN|=(temp) << 19;

 EN_HI();
 EN_LOW();
 LCD_Delay(10);
} 


void LCD_Data(unsigned int data)		   //This function is used to send data to LCD
{
 unsigned int temp=0;
 EN_LOW();
 DATA_PORT();
 WRITE_DATA();
 
 temp=data;
 IO0PIN&=0xFF87FFFF;
 IO0PIN|=(temp & 0xF0) << 15;

 EN_HI();
 EN_LOW();
 
 temp=data & 0x0F;
 
 IO0PIN&=0xFF87FFFF;
 IO0PIN|=(temp) << 19;

 EN_HI();
 EN_LOW();
 LCD_Delay(1);
}

void LCD_Init()
{
 LCD_Command(0x20);
 LCD_Command(0x28);
 LCD_Command(0x0E);
 LCD_Command(0x06);
}


void LCD_String(unsigned char Row,unsigned char Col,unsigned char *data)
{
 LCD_Cursor(Row,Col);
 while(*data)
 {
  LCD_Data(*data);
  data++;
 } 
}


//This function sets cursor position
void LCD_Cursor(unsigned char Row,unsigned char Col)
{
 switch(Row)
 {
  case 1: LCD_Command(0x80+ Col -1);break;
  case 2: LCD_Command(0xC0+ Col -1);break;
  default: break;
 }
}


//This function displays any data upto 5 digits. It also requires row and column address
void LCD_Print(unsigned char Row, char Col,signed int Val, unsigned int Digits)
{
 unsigned char Flag=0;
 unsigned int Temp,Mi,Th,Hu,Te,Un=0;

 if(Row==0 || Col==0)
 {
  LCD_Command(0x80);
 }
 else
 {
  LCD_Cursor(Row,Col);
 }
 if(Digits==5 || Flag==1)
 {
  Mi=Val/10000+48;
  LCD_Data(Mi);
  Flag=1;
 }
 if(Digits==4 || Flag==1)
 {
  Temp = Val/1000;
  Th = (Temp % 10) + 48;
  LCD_Data(Th);
  Flag=1;
 }
 if(Digits==3 || Flag==1)
 {
  Temp = Val/100;
  Hu = (Temp%10) + 48;
  LCD_Data(Hu);
  Flag=1;
 }
 if(Digits==2 || Flag==1)
 {
  Temp = Val/10;
  Te = (Temp%10) + 48;
  LCD_Data(Te);
  Flag=1;
 }
 if(Digits==1 || Flag==1)
 {
  Un = (Val%10) + 48;
  LCD_Data(Un);
 }
 if(Digits>5)
 {
  LCD_Data('E');
 }
	
}




