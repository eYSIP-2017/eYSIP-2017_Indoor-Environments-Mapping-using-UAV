/////////////////////////////////////////////////////////////
//        About Windows driver for URG                     //
//                                         DATE 2009/10/26 //
//                               HOKUYO AUTOMATIC Co.,Ltd. //
/////////////////////////////////////////////////////////////

Thank you very much for purchasing URG sensor.

* Contents
    - README.txt		:This file
    - URG_USB_Driver_VISTA.inf	:Windows driver for URG

* Software Description
    - This driver has been tested in Windows 7, Windows XP and Windows Vista environments.
    - This driver is a common driver for all sensors of URG series.
      (UTM-30LX, UHG-08LX, UBG-04LX-F01, URG-04LX)

* Precautions
The information in this document is subject to change without notice.
All brand names and product names are trademarks or registered trademarks of their respective holders.

* Contact information
If you have any questions or suggestions please contact at
Mail: support@hokuyo-aut.co.jp
