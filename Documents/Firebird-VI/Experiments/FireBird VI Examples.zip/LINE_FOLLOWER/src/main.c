/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "FB6Lib.h"

#define THRESHOLD 100

// TODO: insert other definitions and declarations here
/******************Global Variables****************************/
/**************************************************************/

/******************Function Prototypes****************************/
void InitPeripherals(void);
void Delay1s(void);
void Delay100ms(void);
void LineSensor_ON(void);
void LineSensor_OFF(void);
/*****************************************************************/

/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
	// delay to allow motor controller to initialize
	Delay100ms();

	UARTInit(2, 115200);
	InitMotorController();
	Stop();

	ResetI2C0();
	I2C0Init();
	ResetI2C1();
	I2C1Init();

	// delay to allow LCD to initialize
	Delay1s();
	Delay1s();
	InitLCD();
}

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 100 milliseconds
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : LineSensor_ON();
 Parameters		 : None
 Description 	 : Turns ON line sensor transmitter LED
 Preconditions	 : None
===============================================================================*/
void LineSensor_ON(void)
{
	WLTrigger=1;
	WLTriggerState = 1;		//ON
	WLTriggerUpdate();
}

/*===============================================================================
 Name        	 : LineSensor_OFF();
 Parameters		 : None
 Description 	 : Turns OFF line sensor transmitter LED
 Preconditions	 : None
===============================================================================*/
void LineSensor_OFF(void)
{
	WLTrigger=1;
	WLTriggerState = 0;		//OFF
	WLTriggerUpdate();
}

int main(void) {

	// TODO: insert code here
	uint32_t Tick=0;
	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();

	LCDSetCursorPosition(1,1);
	LCD_WriteStr(20,(uint8_t *)" LINE FOLLOWER DEMO ");


	// Enter an infinite loop
	while(1)
	{
		//LineSensor_ON();						//Turn ON Line Sensor LED
		//Delay();
		Get_Whiteline_Data(Whiteline);			//Get Whiteline Data
		//LineSensor_OFF();						//Turn OFF Line Sensor LED

		if(Whiteline[3]>=THRESHOLD && Whiteline[4]>=THRESHOLD)
		{
			Left_Velocity = 80;
			Right_Velocity = 80;
			Move(Left_Velocity,Right_Velocity);
		}
		else if(Whiteline[3]>=THRESHOLD)
		{
			Left_Velocity = 80;
			Right_Velocity = 95;
			Move(Left_Velocity,Right_Velocity);
		}
		else if(Whiteline[4]>=THRESHOLD)
		{
			Left_Velocity = 95;
			Right_Velocity = 80;
			Move(Left_Velocity,Right_Velocity);
		}
		else if(Whiteline[2]>=THRESHOLD)
		{
			Left_Velocity = 80;
			Right_Velocity = 95;
			Move(Left_Velocity,Right_Velocity);
		}
		else if(Whiteline[1]>=THRESHOLD)
		{
			Left_Velocity = 80;
			Right_Velocity = 110;
			Move(Left_Velocity,Right_Velocity);
		}
		else if(Whiteline[0]>=THRESHOLD)
		{
			Left_Velocity = 80;
			Right_Velocity = 120;
			Move(Left_Velocity,Right_Velocity);
		}
		else if(Whiteline[5]>=THRESHOLD)
		{
			Left_Velocity = 95;
			Right_Velocity = 80;
			Move(Left_Velocity,Right_Velocity);
		}
		else if(Whiteline[6]>=THRESHOLD)
		{
			Left_Velocity = 110;
			Right_Velocity = 80;
			Move(Left_Velocity,Right_Velocity);
		}
		else if(Whiteline[7]>=THRESHOLD)
		{
			Left_Velocity = 120;
			Right_Velocity = 80;
			Move(Left_Velocity,Right_Velocity);
		}
		else
		{
			Left_Velocity = 128;
			Right_Velocity = 128;
			Stop();
		}

		Tick++;
		if(Tick==5)
		{
			LCD_PrintData(2,1,Whiteline[0],3);
			LCD_PrintData(3,2,Whiteline[1],3);
			LCD_PrintData(4,3,Whiteline[2],3);
			LCD_PrintData(4,7,Whiteline[3],3);
			LCD_PrintData(4,11,Whiteline[4],3);
			LCD_PrintData(4,15,Whiteline[5],3);
			LCD_PrintData(3,17,Whiteline[6],3);
			LCD_PrintData(2,18,Whiteline[7],3);
			Tick = 0;
		}


	}
	return 0 ;
}
