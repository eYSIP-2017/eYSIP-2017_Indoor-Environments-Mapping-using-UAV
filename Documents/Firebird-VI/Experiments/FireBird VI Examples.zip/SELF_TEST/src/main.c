/*
===============================================================================
 Name        : main.c
 Author      :
 Version     :
 Copyright   : Copyright (C)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "Hardwareprofile.h"
#include "FB6Lib.h"

// TODO: insert other definitions and declarations here
/******************Global Variables****************************/
/**************************************************************/


/******************Function Prototypes****************************/
void InitLeds(void);
void InitSwitch(void);
void InitPeripherals(void);
void Delay(void);
void BlinkLEDs(void);
void Delay1s(void);
void Delay100ms(void);
void AcquireData(void);
void DelayRotate90(void);
/*****************************************************************/

/*===============================================================================
 Function        : InitLeds()
 Parameters		 : None
 Description 	 : Sets direction of LED IO pins
 Preconditions	 : Uncomment LED definition in Hardwareprofile.h
===============================================================================*/
void InitLeds(void)
{
	LPC_GPIO1->FIODIR&=	!(LED1 | LED2 | LED3 | LED4);
	LPC_GPIO1->FIODIR|= (LED1 | LED2 | LED3 | LED4);
}

/*===============================================================================
 Name        	 : InitSwitch()
 Parameters		 : None
 Description 	 : Sets direction of Switch IO pins
 Preconditions	 : Uncomment SWITCH definition in Hardwareprofile.h
===============================================================================*/
void InitSwitch(void)
{
	LPC_GPIO2->FIODIR&= !(SW1 | SW2 | SW3 | SW4);
}


/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
#if (defined(MOTORCONTROLLER))
	// delay to allow motor controller to initialize
	Delay100ms();

	UARTInit(2, 115200);
	InitMotorController();
	Stop();
#endif

#ifdef LED
	InitLeds();
	BlinkLEDs();
#endif

#ifdef SWITCH
	InitSwitch();
#endif

#if (defined(POT) || defined(SERVOPOD))
	ADCInit(ADC_CLK);
	#if (defined(SERVOPOD))
	LPC_GPIO1->FIODIR|= P1_29;				//Set Direction of trigger pin
	UL_TRIG_OFF();							//Initially ServoPod Ultrasonic Trigger is set OFF
	#endif
#endif

#ifdef SENSORBOARD
	ResetI2C0();
	I2C0Init();
	I2CStop(0);

	#if (defined(WHITELINE))
	//Do Something
	#endif

	#if (defined(ULTRASONIC))
	//Do Something
	#endif

	#if (defined(IR_PROXIMITY))
	//Do Something
	#endif

	#if (defined(EXT_ADC))
	AD7998_WriteReg(AD7998_CONFIG,0x0FF8);		//Convert Channel 1, Filter On
	#endif
#endif

#if (defined(BATTERYMONITOR) || defined(INERTIAL) || defined(LCD))
	ResetI2C1();
	I2C1Init();
	I2CStop(1);

	#if (defined(BATTERYMONITOR))
		//Do Something
	#endif

	#if (defined(GYROSCOPE))
		Init_L3G4200D();
	#endif

	#if (defined(ACCELEROMETER))
		Init_LSM303DLHC_Accelerometer();
	#endif

	#if (defined(MAGNETOMETER))
		Init_LSM303DLHC_Magnetometer();
	#endif

	#if (defined(LCD))
		// delay to allow LCD to initialize
		Delay1s();
		InitLCD();
	#endif

#endif


#if (defined(BEAGLE))
	UARTInit(3, 115200);
#endif

#if (defined(GPS))
	UARTInit(0, 9600);
#endif

#if (defined(WIRELESS_COMMUNICATION))
	UARTInit(1,9600);
	#if (defined(BLUETOOTH))
	//Do Something
	#endif

	#if (defined(XBEE))
	//Do Something
	#endif

	#if (defined(WIFI))
	//Do Something
	#endif
#endif
}

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	//for(i=0;i<10000;i++);
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 100 milliseconds
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

void DelayRotate90(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<45;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : BlinkLEDs();
 Parameters		 : None
 Description 	 : This function blinks the LEDs on GPIO panel
 Preconditions	 : None
===============================================================================*/
void BlinkLEDs(void)
{
	LED1_ON();
	Delay100ms();
	LED1_OFF();
	LED2_ON();
	Delay100ms();
	LED2_OFF();
	LED3_ON();
	Delay100ms();
	LED3_OFF();
	LED4_ON();
	Delay100ms();
	LED4_OFF();
}


/*===============================================================================
 Name        	 : AcquireData();
 Parameters		 : None
 Description 	 : This function acquires data from sensor module, power management module, IMU
 	 	 	 	   and sets actuation signals for traction motors, servo motors, etc.
 Preconditions	 : None
===============================================================================*/
void AcquireData(void)
{
#ifdef BATTERYMONITOR
	Get_Battery_Status(Battery);			//Battery
#endif

#ifdef WHITELINE
	WLTriggerUpdate();
	Get_Whiteline_Data(Whiteline);			//Whiteline
#endif

#ifdef ULTRASONIC
	ULTriggerUpdate();
	Get_Ultrasonic_Data(Ultrasonic);		//Ultrasonic
#endif

#ifdef IR_PROXIMITY
	IRTriggerUpdate();
	Get_IR_Proximity_Data(IR_Proximity);	//IR_Proximity
#endif

#ifdef GYROSCOPE
	Get_XYZ_Rate(Gyroscope);				//Gyroscope
#endif

#ifdef ACCELEROMETER
	Get_XYZ_Acceleration(Accelerometer);	//Accelerometer
#endif

#ifdef MAGNETOMETER
	Get_XYZ_Magnetometer(Magnetometer);		//Magnetometer
#endif

#ifdef MOTORCONTROLLER
	AccelerationUpdate();
	MotorControl();
	if(ResetEncoderCounts==1)
	{
		ClearEncoderCounts();
		ResetEncoderCounts=0;
	}
	Left_Count_New_Locked=GetLeftMotorCount();
	Right_Count_New_Locked = GetRightMotorCount();
#endif

#ifdef POT
	PotValue = ADCRead(5);
#endif

#ifdef SERVOPOD
	ServoPOD_ADC = ADCRead(1);
	if(ServoUpdate==1)
	{
		if		(ServoType==PAN)	{UpdateServoPos(PanAngle,PAN);}
		else if (ServoType==TILT)	{UpdateServoPos(TiltAngle,TILT);}
		else if (ServoType==AUX)	{UpdateServoPos(AuxAngle,AUX);}
	}
#endif


#ifdef EXT_ADC
	Get_AD7998_Data(AD7998ADC);
#endif
}

/******************Type Definitions in stdint.h file*************************

			typedef signed char int8_t;
			typedef unsigned char uint8_t;

			typedef short int16_t;
			typedef unsigned short uint16_t;

			typedef int int32_t;
			typedef unsigned int uint32_t;

****************************************************************************/

int main(void) {

	// TODO: insert code here
	uint32_t Temp=0;
	uint8_t Mode=0;
	uint32_t Tick=0;
	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();

	IRTrigger = 1;
	IRTriggerState = 0;
	WLTrigger = 1;
	WLTriggerState = 0;

	#ifdef LCD
		LCDSetCursorPosition(1,1);
		LCD_WriteStr(20,(uint8_t *)"     SELF TEST      ");
		LCDSetCursorPosition(2,1);
		LCD_WriteStr(20,(uint8_t *)"  PRESS ANY SWITCH  ");

	#endif

	// Enter an infinite loop
	while(1) {
		AcquireData();

		if(!SW1_PRESSED)
		{
			LED1_ON();
			LED2_OFF();
			LED3_OFF();
			LED4_OFF();
			LCDClearScreen();
			Delay();
			LCDSetCursorPosition(1,1);
			LCD_WriteStr(20,(uint8_t *)"  ULTRASONIC DATA   ");
			Mode = 1;
		}
		else if(!SW2_PRESSED)
		{
			LED1_OFF();
			LED2_ON();
			LED3_OFF();
			LED4_OFF();
			LCDClearScreen();
			Delay();
			LCDSetCursorPosition(1,1);
			LCD_WriteStr(20,(uint8_t *)"  LINE SENSOR DATA  ");
			Mode = 2;
		}
		else if(!SW3_PRESSED)
		{
			LED1_OFF();
			LED2_OFF();
			LED3_ON();
			LED4_OFF();
			LCDClearScreen();
			Delay();
			LCDSetCursorPosition(1,1);
			LCD_WriteStr(20,(uint8_t *)"    ACC   GYR   MAG ");
			LCDSetCursorPosition(2,1);
			LCD_WriteStr(1,(uint8_t *)"X");
			LCDSetCursorPosition(3,1);
			LCD_WriteStr(1,(uint8_t *)"Y");
			LCDSetCursorPosition(4,1);
			LCD_WriteStr(1,(uint8_t *)"Z");
			Mode = 3;
		}
		else if(!SW4_PRESSED)
		{
			LED1_OFF();
			LED2_OFF();
			LED3_OFF();
			LED4_ON();
			LCDClearScreen();
			Delay();
			LCDSetCursorPosition(1,1);
			LCD_WriteStr(20,(uint8_t *)"      FBRL DEMO     ");
			Mode = 4;
		}

		switch (Mode)
		{
			case 1:			//Show Ultrasonic Data
			{
				LCD_PrintData(2,1,Ultrasonic[0],3);
				LCD_PrintData(3,2,Ultrasonic[1],3);
				LCD_PrintData(4,3,Ultrasonic[2],3);
				LCD_PrintData(4,7,Ultrasonic[3],3);
				LCD_PrintData(4,11,Ultrasonic[4],3);
				LCD_PrintData(4,15,Ultrasonic[5],3);
				LCD_PrintData(3,17,Ultrasonic[6],3);
				LCD_PrintData(2,18,Ultrasonic[7],3);
				break;
			}
			case 2:			//Show LIne Sensor Data
			{
				LCD_PrintData(2,1,Whiteline[0],3);
				LCD_PrintData(3,2,Whiteline[1],3);
				LCD_PrintData(4,3,Whiteline[2],3);
				LCD_PrintData(4,7,Whiteline[3],3);
				LCD_PrintData(4,11,Whiteline[4],3);
				LCD_PrintData(4,15,Whiteline[5],3);
				LCD_PrintData(3,17,Whiteline[6],3);
				LCD_PrintData(2,18,Whiteline[7],3);
				break;
			}
			case 3:			//Show IMU Data
			{
				Tick++;
				if(Tick==50)
				{
					/****************Accelerometer ***********************************/
					Temp = Accelerometer[0] & 0x00FF;
					Temp|= (uint32_t)Accelerometer[1] << 8;
					LCD_PrintData(2,4,Temp,5);			//Print Accelerometer X axis

					Temp = Accelerometer[2] & 0x00FF;
					Temp|= (uint32_t)Accelerometer[3] << 8;
					LCD_PrintData(3,4,Temp,5);			//Print Accelerometer Y axis

					Temp = Accelerometer[4] & 0x00FF;
					Temp|= (uint32_t)Accelerometer[5] << 8;
					LCD_PrintData(4,4,Temp,5);			//Print Accelerometer Z axis
					/*************************************************************/

					/****************Gyroscope ***********************************/
					Temp = Gyroscope[0] & 0x00FF;
					Temp|= (uint32_t)Gyroscope[1] << 8;
					LCD_PrintData(2,10,Temp,5);			//Print Gyroscope X axis

					Temp = Gyroscope[2] & 0x00FF;
					Temp|= (uint32_t)Gyroscope[3] << 8;
					LCD_PrintData(3,10,Temp,5);			//Print Gyroscope Y axis

					Temp = Gyroscope[4] & 0x00FF;
					Temp|= (uint32_t)Gyroscope[5] << 8;
					LCD_PrintData(4,10,Temp,5);			//Print Gyroscope Z axis
					/*************************************************************/

					/****************Magnetometer ***********************************/
					Temp = Magnetometer[1] & 0x00FF;
					Temp|= (uint32_t)Magnetometer[0] << 8;
					LCD_PrintData(2,16,Temp,5);			//Print Magnetometer X axis

					Temp = Magnetometer[3] & 0x00FF;
					Temp|= (uint32_t)Magnetometer[2] << 8;
					LCD_PrintData(3,16,Temp,5);			//Print Magnetometer Y axis

					Temp = Magnetometer[5] & 0x00FF;
					Temp|= (uint32_t)Magnetometer[4] << 8;
					LCD_PrintData(4,16,Temp,5);			//Print Magnetometer Z axis
					/*************************************************************/
					Tick = 0;
				}
				break;
			}
			case 4:		//Perform FBRL
			{
				Move(35,35);
				Delay1s();
				Stop();
				Delay1s();
				Move(-35,-35);
				Delay1s();
				Stop();
				Delay1s();
				Move(-35,35);
				DelayRotate90();
				Stop();
				Delay1s();
				Move(35,-35);
				DelayRotate90();
				DelayRotate90();
				Stop();
				Delay1s();
				Move(-35,35);
				DelayRotate90();
				Stop();
				Delay1s();
				Mode = 0;
				break;
			}
			default:
				break;
		}



	}
	return 0 ;
}
