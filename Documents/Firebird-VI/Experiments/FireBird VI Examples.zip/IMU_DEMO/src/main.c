/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "FB6Lib.h"

// TODO: insert other definitions and declarations here
/******************Global Variables****************************/

/**************************************************************/

/******************Function Prototypes****************************/
void InitPeripherals(void);
void Delay(void);
void Delay1s(void);
void Delay100ms(void);
/*****************************************************************/

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	//for(i=0;i<10000;i++);
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 100 milliseconds
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
	// delay to allow motor controller to initialize
	Delay100ms();

	UARTInit(2, 115200);
	InitMotorController();
	Stop();

	ResetI2C1();
	I2C1Init();
	Init_L3G4200D();
	Init_LSM303DLHC_Accelerometer();
	Init_LSM303DLHC_Magnetometer();

	// delay to allow LCD to initialize
	Delay1s();
	InitLCD();
}


int main(void) {
	
	// TODO: insert code here
	uint32_t Tick=0;
	uint32_t Temp=0;
	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();
	Delay1s();

	LCDSetCursorPosition(1,1);
	LCD_WriteStr(20,(uint8_t *)"    ACC   GYR   MAG ");
	LCDSetCursorPosition(2,1);
	LCD_WriteStr(1,(uint8_t *)"X");
	LCDSetCursorPosition(3,1);
	LCD_WriteStr(1,(uint8_t *)"Y");
	LCDSetCursorPosition(4,1);
	LCD_WriteStr(1,(uint8_t *)"Z");
	// Enter an infinite loop
	while(1)
	{
		Get_XYZ_Rate(Gyroscope);				//Gyroscope
		Get_XYZ_Acceleration(Accelerometer);	//Accelerometer
		Get_XYZ_Magnetometer(Magnetometer);		//Magnetometer

		Tick++;
		if(Tick==100)
		{
			/****************Accelerometer ***********************************/
			Temp = Accelerometer[0] & 0x00FF;
			Temp|= (uint32_t)Accelerometer[1] << 8;
			LCD_PrintData(2,4,Temp,5);			//Print Accelerometer X axis

			Temp = Accelerometer[2] & 0x00FF;
			Temp|= (uint32_t)Accelerometer[3] << 8;
			LCD_PrintData(3,4,Temp,5);			//Print Accelerometer Y axis

			Temp = Accelerometer[4] & 0x00FF;
			Temp|= (uint32_t)Accelerometer[5] << 8;
			LCD_PrintData(4,4,Temp,5);			//Print Accelerometer Z axis
			/*************************************************************/

			/****************Gyroscope ***********************************/
			Temp = Gyroscope[0] & 0x00FF;
			Temp|= (uint32_t)Gyroscope[1] << 8;
			LCD_PrintData(2,10,Temp,5);			//Print Gyroscope X axis

			Temp = Gyroscope[2] & 0x00FF;
			Temp|= (uint32_t)Gyroscope[3] << 8;
			LCD_PrintData(3,10,Temp,5);			//Print Gyroscope Y axis

			Temp = Gyroscope[4] & 0x00FF;
			Temp|= (uint32_t)Gyroscope[5] << 8;
			LCD_PrintData(4,10,Temp,5);			//Print Gyroscope Z axis
			/*************************************************************/

			/****************Magnetometer ***********************************/
			Temp = Magnetometer[1] & 0x00FF;
			Temp|= (uint32_t)Magnetometer[0] << 8;
			LCD_PrintData(2,16,Temp,5);			//Print Magnetometer X axis

			Temp = Magnetometer[3] & 0x00FF;
			Temp|= (uint32_t)Magnetometer[2] << 8;
			LCD_PrintData(3,16,Temp,5);			//Print Magnetometer Y axis

			Temp = Magnetometer[5] & 0x00FF;
			Temp|= (uint32_t)Magnetometer[4] << 8;
			LCD_PrintData(4,16,Temp,5);			//Print Magnetometer Z axis
			/*************************************************************/
			Tick = 0;
		}


	}
	return 0 ;
}
