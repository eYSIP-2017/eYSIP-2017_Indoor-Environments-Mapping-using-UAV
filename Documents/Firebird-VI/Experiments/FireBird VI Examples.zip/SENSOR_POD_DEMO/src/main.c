/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "Hardwareprofile.h"
#include "FB6Lib.h"

// TODO: insert other definitions and declarations here

extern uint32_t ServoPOD_ADC;

/******************Function Prototypes****************************/
void InitPeripherals(void);
void Delay(void);
void Delay1s(void);
void Delay100ms(void);
/*****************************************************************/

/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
	LPC_GPIO1->FIODIR|= P1_29;				//Set Direction of trigger pin

#if (defined(MOTORCONTROLLER))
	// delay to allow motor controller to initialize
	Delay100ms();

	UARTInit(2, 115200);
	InitMotorController();
	Stop();
#endif

	ResetI2C0();
	I2C0Init();

	UL_TRIG_OFF();							//Initially ServoPod Ultrasonic OFF
	ADCInit(ADC_CLK);

	ResetI2C1();
	I2C1Init();

	// delay to allow LCD to initialize
	Delay1s();
	InitLCD();
}


/*===============================================================================
	 Name        	 : Delay();
	 Parameters		 : None
	 Description 	 : Generates delay of very small amount
	 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	for(i=0;i<100;i++);
}

/*===============================================================================
	 Name        	 : Delay1s();
	 Parameters		 : None
	 Description 	 : Generates delay of approximately 1 Second
	 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 100 milliseconds
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}


int main(void) {
	
	// TODO: insert code here
	SystemInit();			/*Init PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();
	Delay1s();

	// set tilt servo to 90 degrees
	UpdateServoPos(90,TILT);
	UL_TRIG_ON();

	// change pan servo angle step by step
	UpdateServoPos(0,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(1,1,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(12,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(1,6,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(24,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(1,11,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(36,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(1,16,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(48,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(2,1,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(60,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(2,6,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(72,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(2,11,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(84,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(2,16,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(96,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(3,1,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(108,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(3,6,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(120,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(3,11,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(132,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(3,16,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(144,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(4,1,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(156,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(4,6,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(168,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(4,11,ServoPOD_ADC,4);
	Delay1s();

	UpdateServoPos(180,PAN);
	ServoPOD_ADC = ADCRead(1);
	LCD_PrintData(4,16,ServoPOD_ADC,4);
	Delay1s();

	while(1)
	{



	}
	return 0;
}
