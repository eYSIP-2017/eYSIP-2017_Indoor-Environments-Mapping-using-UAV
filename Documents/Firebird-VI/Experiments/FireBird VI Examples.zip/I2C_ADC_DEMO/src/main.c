/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "FB6Lib.h"

// TODO: insert other definitions and declarations here
/******************Global Variables****************************/

/**************************************************************/

/******************Function Prototypes****************************/
void InitPeripherals(void);
void Delay(void);
void Delay1s(void);
void Delay100ms(void);
/*****************************************************************/


/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
	// delay to allow motor controller to initialize
	Delay100ms();

	UARTInit(2, 115200);
	InitMotorController();
	Stop();

	ResetI2C0();
	I2C0Init();
	AD7998_WriteReg(AD7998_CONFIG,0x0FF8);		//Convert Channel 1, Filter On
	ResetI2C1();
	I2C1Init();

	// delay to allow LCD to initialize
	Delay1s();
	InitLCD();
}


/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	//for(i=0;i<10000;i++);
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 100 milliseconds
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

int main(void) {
	
	// TODO: insert code here
	uint32_t Tick=0;
	uint32_t Temp=0;
	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();
	Delay1s();

	LCDSetCursorPosition(1,1);
	LCD_WriteStr(20,(uint8_t *)"    I2C ADC DEMO    ");

	// Enter an infinite loop
	while(1)
	{
		Get_AD7998_Data(AD7998ADC);
		Tick++;
		if(Tick==100)
		{
			Temp = AD7998ADC[0];
			Temp|= ((uint32_t) (AD7998ADC[1] & 0x0F)) << 8;
			LCD_PrintData(3,1,Temp,4);

			Temp = AD7998ADC[2];
			Temp|= ((uint32_t) (AD7998ADC[3] & 0x0F)) << 8;
			LCD_PrintData(3,6,Temp,4);

			Temp = AD7998ADC[4];
			Temp|= ((uint32_t) (AD7998ADC[5] & 0x0F)) << 8;
			LCD_PrintData(3,11,Temp,4);

			Temp = AD7998ADC[6];
			Temp|= ((uint32_t) (AD7998ADC[7] & 0x0F)) << 8;
			LCD_PrintData(3,16,Temp,4);

			Temp = AD7998ADC[8];
			Temp|= ((uint32_t) (AD7998ADC[9] & 0x0F)) << 8;
			LCD_PrintData(4,1,Temp,4);

			Temp = AD7998ADC[10];
			Temp|= ((uint32_t) (AD7998ADC[11] & 0x0F)) << 8;
			LCD_PrintData(4,6,Temp,4);

			Temp = AD7998ADC[12];
			Temp|= ((uint32_t) (AD7998ADC[13] & 0x0F)) << 8;
			LCD_PrintData(4,11,Temp,4);

			Temp = AD7998ADC[14];
			Temp|= ((uint32_t) (AD7998ADC[15] & 0x0F)) << 8;
			LCD_PrintData(4,16,Temp,4);

			Tick = 0;
		}
	}
	return 0 ;
}
