/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "type.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here
#include "HardwareDefinition.h"
#include "Hardwareprofile.h"
#include "FB6Lib.h"


// TODO: insert other definitions and declarations here


/**************************************************************/

/******************Function Prototypes****************************/
void InitLeds(void);
void InitSwitch(void);
void InitPeripherals(void);
void Delay(void);
void BlinkLEDs(void);
void Delay1s(void);
void Delay100ms(void);
void AcquireData(void);
void DelayRotate90(void);
/*****************************************************************/

/*===============================================================================
 Function        : InitLeds()
 Parameters		 : None
 Description 	 : Sets direction of LED IO pins
 Preconditions	 : Uncomment LED definition in Hardwareprofile.h
===============================================================================*/
void InitLeds(void)
{
	LPC_GPIO1->FIODIR&=	!(LED1 | LED2 | LED3 | LED4);
	LPC_GPIO1->FIODIR|= (LED1 | LED2 | LED3 | LED4);
}

/*===============================================================================
 Name        	 : InitSwitch()
 Parameters		 : None
 Description 	 : Sets direction of Switch IO pins
 Preconditions	 : Uncomment SWITCH definition in Hardwareprofile.h
===============================================================================*/
void InitSwitch(void)
{
	LPC_GPIO2->FIODIR&= !(SW1 | SW2 | SW3 | SW4);
}


/*===============================================================================
 Name        	 : InitPeripherals()
 Parameters		 : None
 Description 	 : This function initializes the peripherals of LPC1769 microcontroller
 	 	 	 	   and modules of Fire Bird VI robot as per the definitions in
 	 	 	 	   Hardwareprofile.h
 Preconditions	 : None
===============================================================================*/
void InitPeripherals(void)
{
#if (defined(MOTORCONTROLLER))
	// delay to allow motor controller to initialize
	Delay100ms();

	UARTInit(2, 115200);
	InitMotorController();
	Mode = 1;
	SetMode(Mode);
	Stop();
#endif

#ifdef LED
	InitLeds();
	BlinkLEDs();
#endif

#ifdef SWITCH
	InitSwitch();
#endif

#if (defined(POT) || defined(SERVOPOD))
	ADCInit(ADC_CLK);
#if (defined(SERVOPOD))
	LPC_GPIO1->FIODIR|= P1_29;				//Set Direction of trigger pin
	UL_TRIG_OFF();							//Initially ServoPod Ultrasonic Trigger is set OFF
#endif
#endif

#ifdef SENSORBOARD
	ResetI2C0();
	I2C0Init();
	I2CStop(0);

#if (defined(WHITELINE))
	//Write Code here
#endif

#if (defined(ULTRASONIC))
	//Write Code here
#endif

#if (defined(IR_PROXIMITY))
	//Write Code here
#endif

#if (defined(EXT_ADC))
	AD7998_WriteReg(AD7998_CONFIG,0x0FF8);		//Convert Channel 1, Filter On
#endif
#endif

#if (defined(BATTERYMONITOR) || defined(INERTIAL) || defined(LCD))
	ResetI2C1();
	I2C1Init();
	I2CStop(1);

#if (defined(BATTERYMONITOR))
	//Write Code here
#endif

#if (defined(GYROSCOPE))
		Init_L3G4200D();
#endif

#if (defined(ACCELEROMETER))
		Init_LSM303DLHC_Accelerometer();
#endif

#if (defined(MAGNETOMETER))
		Init_LSM303DLHC_Magnetometer();
#endif

#if (defined(LCD))
		// delay to allow LCD to initialize
		Delay1s();
		InitLCD();
#endif

#endif


#if (defined(BEAGLE))
	UARTInit(3, 115200);
#endif

#if (defined(GPS))
	UARTInit(0, 9600);
#endif

#if (defined(WIRELESS_COMMUNICATION))
	UARTInit(1,115200);
#if (defined(BLUETOOTH))
	//Write Code here
#endif

#if (defined(XBEE))
	//Write Code here
#endif

#if (defined(WIFI))
	//Write Code here
#endif
#endif
}

/*===============================================================================
 Name        	 : Delay();
 Parameters		 : None
 Description 	 : Generates delay of very small amount
 Preconditions	 : None
===============================================================================*/
void Delay(void)
{
	uint32_t i=0;
	for(i=0;i<100;i++);
}

/*===============================================================================
 Name        	 : Delay100ms();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay100ms(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<11;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : Delay1s();
 Parameters		 : None
 Description 	 : Generates delay of approximately 1 Second
 Preconditions	 : None
===============================================================================*/
void Delay1s(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<110;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

void DelayRotate90(void)
{
	volatile uint32_t i=0;
	volatile uint32_t k=0;
	volatile uint32_t j=0;
	for(k=0;k<45;k++)
	{
		for(i=0;i<60000;i++)
		{
			j++;
		}
	}
}

/*===============================================================================
 Name        	 : BlinkLEDs();
 Parameters		 : None
 Description 	 : This function blinks the LEDs on GPIO panel
 Preconditions	 : None
===============================================================================*/
void BlinkLEDs(void)
{
	LED1_ON();
	Delay100ms();
	LED1_OFF();
	LED2_ON();
	Delay100ms();
	LED2_OFF();
	LED3_ON();
	Delay100ms();
	LED3_OFF();
	LED4_ON();
	Delay100ms();
	LED4_OFF();
}

void updateMotion(uint8_t *channelData)
{
	if(channelData[0] > 70)
	{
		Move(40,~40);
	}
	else if(channelData[0] < 30)
	{
		Move(~40, 40);
	}
	else if(channelData[1] > 70)
	{
		Move(40,40);
	}
	else if(channelData[1] < 30)
	{
		Move(~40, ~40);
	}
	else
		Move(128,128);

}

/******************Type Definitions in stdint.h file*************************

			typedef signed char int8_t;
			typedef unsigned char uint8_t;

			typedef short int16_t;
			typedef unsigned short uint16_t;

			typedef int int32_t;
			typedef unsigned int uint32_t;

****************************************************************************/

int main(void) {
	
	// TODO: insert code here
	uint32_t Tick=0;
	uint8_t channelData[6] = {0,0,0,0,0,0};
	uint8_t getRemoteData[4] = {0x4E, 0x45, 0x58, 0x25};

	SystemInit();			/*Inits PLL and Peripheral Clocks*/	//Core Clock(CCLK) = 120MHz, All Peripheral Clock = 1/4 * CCLK
	SystemClockUpdate();	/* SystemClockUpdate() updates the SystemFrequency variable */
	InitPeripherals();

	IRTrigger = 1;
	IRTriggerState = 0;
	WLTrigger = 1;
	WLTriggerState = 0;

#ifdef LCD
	LCDSetCursorPosition(1,1);
	LCD_WriteStr(20,(uint8_t *)"2.4 GHz Remote DEMO ");
	LCDSetCursorPosition(2,1);	LCD_WriteStr(4,(uint8_t *)"CH1:");
	LCDSetCursorPosition(3,1);  LCD_WriteStr(4,(uint8_t *)"CH2:");
	LCDSetCursorPosition(4,1);  LCD_WriteStr(4,(uint8_t *)"CH3:");
	LCDSetCursorPosition(2,11);  LCD_WriteStr(4,(uint8_t *)"CH4:");
	LCDSetCursorPosition(3,11);  LCD_WriteStr(4,(uint8_t *)"CH5:");
	LCDSetCursorPosition(4,11);  LCD_WriteStr(4,(uint8_t *)"CH6:");
#endif

	// Enter an infinite loop
	while(1) {


		if(updateRemote_2_4GhzCommand == 1)
		{
			channelData[0] = remoteControl[0];
			channelData[1] = remoteControl[1];
			channelData[2] = remoteControl[2];
			channelData[3] = remoteControl[3];
			channelData[4] = remoteControl[4];
			channelData[5] = remoteControl[5];
			updateRemote_2_4GhzCommand = 0;

			updateMotion(channelData);
		}

#ifdef LCD
		Tick++;
		if(Tick==10)
		{
			UARTSend(1, getRemoteData, 4);
			Delay100ms();										// delay for reducing LCD refresh rate
			LCD_PrintData(2,5,(uint32_t)channelData[0],3);
			LCD_PrintData(3,5,(uint32_t)channelData[1],3);
			LCD_PrintData(4,5,(uint32_t)channelData[2],3);
			LCD_PrintData(2,15,(uint32_t)channelData[3],3);
			LCD_PrintData(3,15,(uint32_t)channelData[4],3);
			LCD_PrintData(4,15,(uint32_t)channelData[5],3);
			Tick = 0;
		}
#endif

	}
	return 0 ;
}
